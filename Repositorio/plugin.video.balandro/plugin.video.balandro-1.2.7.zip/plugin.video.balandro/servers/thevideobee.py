# -*- coding: utf-8 -*-

from core import httptools, scrapertools
from platformcode import logger


def test_video_exists(page_url):
    logger.info("(page_url='%s')" % page_url)
    data = httptools.downloadpage(page_url).data
    if '404 Not Found' in data:
        return False, "[thevideobee] El archivo ha sido eliminado o no existe"
    return True, ""


def get_video_url(page_url, premium=False, user="", password="", video_password=""):
    logger.info("url=" + page_url)
    video_urls = []

    data = httptools.downloadpage(page_url).data
    # ~ logger.debug(data)

    url = scrapertools.find_single_match(data, 'src\s*:\s*"([^"]+)')
    if url != '':
        video_urls.append(['[thevideobee]', url])

    return video_urls
