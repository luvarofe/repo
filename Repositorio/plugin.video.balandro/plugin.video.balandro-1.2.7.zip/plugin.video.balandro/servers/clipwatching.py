# -*- coding: utf-8 -*-

from core import httptools
from core import scrapertools
from lib import jsunpack
from platformcode import logger, config


def test_video_exists(page_url):
    logger.info("(page_url='%s')" % page_url)
    data = httptools.downloadpage(page_url).data
    if "File Not Found" in data or "File was deleted" in data:
        return False, '[ClipWatching] El archivo ya no está presente en el servidor'
    return True, ""


def get_video_url(page_url, user="", password="", video_password=""):
    logger.info("(page_url='%s')" % page_url)
    data = httptools.downloadpage(page_url).data
    packed = scrapertools.find_single_match(data, "text/javascript'>(.*?)\s*</script>")
    unpacked = jsunpack.unpack(packed)
    video_urls = []
    videos = scrapertools.find_multiple_matches(unpacked, 'file:"([^"]+).*?label:"([^"]+)')
    for video, label in videos:
        if ".jpg" not in video:
            video_urls.append([label + " [clipwatching]", video])
    video_urls.sort(key=lambda it: int(it[0].split("p ", 1)[0]))
    return video_urls
